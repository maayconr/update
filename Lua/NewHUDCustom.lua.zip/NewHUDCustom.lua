require "System\\ScriptCore"

--ConsoleOn(1)

local IMAGE_MENU_1 = 312910
local IMAGE_MENU_2 = 312920
local IMAGE_MENU_3 = 312930
local IMAGE_MENU_2_1 = 312950
local IMAGE_GAUGE_BLUE = 312960
local IMAGE_GAUGE_GREEN = 312970
local IMAGE_GAUGE_RED = 312980
local IMAGE_GAUGE_AG = 312990
local IMAGE_GAUGE_SD = 313000
local IMAGE_MENU_BTN_CSHOP = 313030
local IMAGE_MENU_BTN_CHAINFO = 313040
local IMAGE_MENU_BTN_MYINVEN = 313050
local IMAGE_MENU_BTN_FRIEND = 313060
local IMAGE_MENU_BTN_WINDOW = 313070
local IMAGE_MENU_BTN_GUILD = 313080

local CLOCKS_PER_SEC = 1000

local SOUND_HEART = 34 -- Som de batimento cardíaco

function LoadHudImage() -- Carregamento das imagens do client
	LoadImage("Interface\\NewHud\\Custom\\newui_menu01.tga", IMAGE_MENU_1)
	LoadImage("Interface\\NewHud\\Custom\\newui_menu02.tga", IMAGE_MENU_2)
	LoadImage("Interface\\NewHud\\Custom\\newui_menu03.tga", IMAGE_MENU_3)
	LoadImage("Interface\\NewHud\\Custom\\newui_menu_blue.tga", IMAGE_GAUGE_BLUE)
	LoadImage("Interface\\NewHud\\Custom\\newui_menu_green.tga", IMAGE_GAUGE_GREEN)
	LoadImage("Interface\\NewHud\\Custom\\newui_menu_red.tga", IMAGE_GAUGE_RED)
	LoadImage("Interface\\NewHud\\Custom\\newui_menu_ag.jpg", IMAGE_GAUGE_AG)
	LoadImage("Interface\\NewHud\\Custom\\newui_menu_sd.jpg", IMAGE_GAUGE_SD)
	LoadImage("Interface\\NewHud\\Custom\\newui_menu_Bt01.tga", IMAGE_MENU_BTN_CHAINFO)
	LoadImage("Interface\\NewHud\\Custom\\newui_menu_Bt02.tga", IMAGE_MENU_BTN_MYINVEN)
	LoadImage("Interface\\NewHud\\Custom\\newui_menu_Bt03.tga", IMAGE_MENU_BTN_FRIEND)
	LoadImage("Interface\\NewHud\\Custom\\newui_menu_Bt04.tga", IMAGE_MENU_BTN_WINDOW)
	LoadImage("Interface\\NewHud\\Custom\\newui_menu_Bt05.tga", IMAGE_MENU_BTN_CSHOP)
	LoadImage("Interface\\NewHud\\Custom\\newui_menu_Bt06.tga", IMAGE_MENU_BTN_GUILD)
end

function RenderFrameAnimation(Image, x, y, w, h, u, v, uw, vh, Time, cols, totalFrames, uFrame, vFrame) -- Função auxiliar para animar Life e Mana
	local factor = totalFrames / (Time * CLOCKS_PER_SEC)
	local frame = math.floor(GetTickCount() * factor) % totalFrames

	local fx = (frame % cols) * (uFrame ~= 0 and uFrame or uw)
	local fy = math.floor(frame / cols) * (vFrame ~= 0 and vFrame or vh)

	RenderImage(Image, x, y, w, h, u + fx, v + fy, uw, vh)
end

function clamp(value, minVal, maxVal) -- Função auxiliar para cálculo
	return math.min(math.max(value, minVal), maxVal)
end

function RenderLife() -- Calculo e renderização das barras de Life e Mana
	local fLife = 0.0
	local fMana = 0.0

	local wLifeMax
	local wLife
	local wManaMax
	local wMana

	wLifeMax = ViewMaxHP()
	wLife = clamp(ViewCurHP(), 0, wLifeMax)
	wManaMax = ViewMaxMP()
	wMana = clamp(ViewCurMP(), 0, wManaMax)

	if wLifeMax > 0 and (wLife > 0 and (wLife / wLifeMax) < 0.2) then
		PlaySound(SOUND_HEART);
	end

	if wLifeMax > 0 then
		fLife = (wLifeMax - wLife) / wLifeMax
	end
	
	if wManaMax > 0 then
		fMana = (wManaMax - wMana) / wManaMax
	end

	local frameX = ((GetWindowsX() / 2.0) - 320.0)
	local frameY = (GetWindowsY() - 72.0)

	local width = 60.0
	local height = 60.0
	local porcento = (1.0 - fLife)

	local iPosX = frameX + 108
	local iPosY = frameY + (fLife * height)
	local Height = (porcento * height)

	RenderImage(IMAGE_MENU_3, iPosX, frameY, width, height, 2.0, 2.0, 158.0, 158.0)

	if IsBuffPoison() then
		RenderFrameAnimation(IMAGE_GAUGE_GREEN, iPosX, iPosY, width, Height, 0.0, (fLife * 152.0), 152.0, (porcento * 152.0), 1.44, 6, 36, 0.0, 152.0)
	else
		RenderFrameAnimation(IMAGE_GAUGE_RED, iPosX, iPosY, width, Height, 0.0, (fLife * 152.0), 152.0, (porcento * 152.0), 1.44, 6, 36, 0.0, 152.0)
	end

	porcento = (1.0 - fMana)

	iPosX = frameX + 465
	iPosY = frameY + (fMana * height)
	Height = (porcento * height)

	RenderImage(IMAGE_MENU_3, iPosX, frameY, width, height, 160, 2.0, -158.0, 158.0)

	RenderFrameAnimation(IMAGE_GAUGE_BLUE, iPosX, iPosY, width, Height, 0.0, (fMana * 152.0), 152.0, (porcento * 152.0), 1.44, 6, 36, 0.0, 152.0)
end

function RenderLifeHub() -- Renderização do ToolTip de Life e Mana
	local wLifeMax
	local wLife
	local wManaMax
	local wMana

	wLifeMax = ViewMaxHP()
	wLife = clamp(ViewCurHP(), 0, wLifeMax)
	wManaMax = ViewMaxMP()
	wMana = clamp(ViewCurMP(), 0, wManaMax)
	
	local frameX = ((GetWindowsX() / 2.0) - 320.0) + 108.0
	local frameY = (GetWindowsY() - 72.0)

	DrawBigNumber(frameX + 30.0, frameY + 30.0, wLife, 0.8)

	local strTipText1 = ""
	if CheckMouseIn(frameX, frameY, 60.0, 60.0) then
		strTipText1 = string.format("%d / %d", wLife, wLifeMax)
		ToolTipText(frameX, (frameY - 16), strTipText1)
	end

	frameX = frameX + 357.0

	DrawBigNumber(frameX + 35.0, frameY + 30.0, wMana, 0.8)

	local strTipText2 = ""
	if CheckMouseIn(frameX, frameY, 60.0, 60.0) then
		strTipText2 = string.format("%d / %d", wMana, wManaMax)
		ToolTipText(frameX, (frameY - 16), strTipText2)
	end
end

function RenderEnergy() -- Calculo e renderização da barra de AG e ToolTip
	local fSkillMana = 0.0
	local dwMaxSkillMana = ViewMaxBP()
	local dwSkillMana = ViewCurBP()

	if dwMaxSkillMana > 0 then
		fSkillMana = (dwMaxSkillMana - dwSkillMana) / dwMaxSkillMana
	end
	
	local frameX = ((GetWindowsX() / 2.0) - 320.0) + 396.0
	local frameY = (GetWindowsY() - 72.0) + 19.0

	local width = 68.0
	local height = 9.0
	local porcento = (1.0 - fSkillMana)

	local iPosX = frameX + (fSkillMana * width)
	local Width = (porcento * width)

	glColor(255, 255, 255, 255)

	RenderImage(IMAGE_GAUGE_AG, iPosX, frameY, Width, height, (fSkillMana * 122.0), 0.0, (porcento * 122.0), 16.0)

	DrawBigNumber(frameX + 35.0, frameY + 1.0, dwSkillMana, 0.8)

	local strText = ""
	if CheckMouseIn(frameX, frameY, width, height) then
		strText = string.format("%d / %d", dwSkillMana, dwMaxSkillMana)
		ToolTipText(frameX, (frameY - 16), strText)
	end
end

function RenderShield() -- Calculo e renderização da barra de SD e ToolTip
	local fShield = 0.0
	local wMaxShield = ViewMaxSD()
	local wShield = ViewCurSD()

	if wMaxShield > 0 then
		fShield = (wMaxShield - wShield) / wMaxShield
	end

	local frameX = ((GetWindowsX() / 2.0) - 320.0) + 178
	local frameY = (GetWindowsY() - 72.0) + 19.0

	local width = 68.0
	local height = 9.0
	local porcento = (1.0 - fShield)
	
	local Width = (porcento * width)

	glColor(255, 255, 255, 255)

	RenderImage(IMAGE_GAUGE_SD, frameX, frameY, Width, height, 0.0, 0.0, (porcento * 122.0), 16.0)

	DrawBigNumber(frameX + 35.0, frameY + 1.0, wShield, 0.8)

	local strText = ""
	if CheckMouseIn(frameX, frameY, width, height) then
		strText = string.format("%d / %d", wShield, wMaxShield)
		ToolTipText(frameX, (frameY - 16), strText)
	end
end

function HudButtonsRender()
	local frameX = ((GetWindowsX() / 2.0) - 277.0)
	local frameY = (GetWindowsY() - 32.0)

	-- Renderiza o botão 1
	local ChangeMap1 = 4.0
	if CheckWindow(65) == true then ChangeMap1 = 118.0 end
	if CheckMouseIn(frameX, frameY, 21.0, 22.0) then if IsRepeat(1) then ChangeMap1 = 80.0 else ChangeMap1 = 42.0 end end
	RenderImage(IMAGE_MENU_BTN_CSHOP, frameX, frameY, 21.0, 22.0, 3.0, ChangeMap1, 30.0, 30.0)

	-- Renderiza o botão 2
	local ChangeMap2 = 4.0
	frameX = frameX + 24.0 frameY = frameY + 0.5
	if CheckWindow(16) == true then ChangeMap2 = 118.0 end
	if CheckMouseIn(frameX, frameY, 21.0, 22.0) then if IsRepeat(1) then ChangeMap2 = 80.0 else ChangeMap2 = 42.0 end end
	RenderImage(IMAGE_MENU_BTN_CHAINFO, frameX, frameY, 21.0, 22.0, 3.0, ChangeMap2, 30.0, 30.0)

	-- Renderiza o botão 3
	local ChangeMap3 = 4.0
	frameX = frameX + 24.0 frameY = frameY - 1.0
	if CheckWindow(13) == true then ChangeMap3 = 118.0 end
	if CheckMouseIn(frameX, frameY, 21.0, 22.0) then if IsRepeat(1) then ChangeMap3 = 80.0 else ChangeMap3 = 42.0 end end
	RenderImage(IMAGE_MENU_BTN_MYINVEN, frameX, frameY, 21.0, 22.0, 3.0, ChangeMap3, 30.0, 30.0)

	-- Renderiza o botão 4
	local ChangeMap3 = 4.0
	frameX = frameX + 436.0 frameY = frameY + 1.0
	if CheckWindow(6) == true then ChangeMap3 = 118.0 end
	if CheckMouseIn(frameX, frameY, 21.0, 22.0) then if IsRepeat(1) then ChangeMap3 = 80.0 else ChangeMap3 = 42.0 end end
	RenderImage(IMAGE_MENU_BTN_GUILD, frameX, frameY, 21.0, 22.0, 3.0, ChangeMap3, 30.0, 30.0)

	-- Renderiza o botão 5
	local ChangeMap3 = 4.0
	frameX = frameX + 24.0 frameY = frameY + 0.5
	if CheckWindow(1) == true then ChangeMap3 = 118.0 end
	if CheckMouseIn(frameX, frameY, 21.0, 22.0) then if IsRepeat(1) then ChangeMap3 = 80.0 else ChangeMap3 = 42.0 end end
	RenderImage(IMAGE_MENU_BTN_FRIEND, frameX, frameY, 21.0, 22.0, 3.0, ChangeMap3, 30.0, 30.0)

	-- Renderiza o botão 6
	local ChangeMap3 = 4.0
	frameX = frameX + 24.0 frameY = frameY - 0.5
	if CheckWindow(34) == true then ChangeMap3 = 118.0 end
	if CheckMouseIn(frameX, frameY, 21.0, 22.0) then if IsRepeat(1) then ChangeMap3 = 80.0 else ChangeMap3 = 42.0 end end
	RenderImage(IMAGE_MENU_BTN_WINDOW, frameX, frameY, 21.0, 22.0, 3.0, ChangeMap3, 30.0, 30.0)
end

function HudButtonsEvent()
	local frameX = ((GetWindowsX() / 2.0) - 277.0)
	local frameY = (GetWindowsY() - 32.0)

	-- Evento abrir CashShop do botão 1
	if CheckMouseIn(frameX, frameY, 21.0, 22.0) and IsRelease(1) then if CheckWindow(65) then CloseWindow(65) else CashShopSwitchState() end end

	-- Evento abrir Character do botão 2
	frameX = frameX + 24.0 frameY = frameY + 0.5
	if CheckMouseIn(frameX, frameY, 21.0, 22.0) and IsRelease(1) then if CheckWindow(16) then CloseWindow(16) else OpenWindow(16) end end

	-- Evento abrir Inventory do botão 3
	frameX = frameX + 24.0 frameY = frameY - 1.0
	if CheckMouseIn(frameX, frameY, 21.0, 22.0) and IsRelease(1) then if CheckWindow(13) then CloseWindow(13) else OpenWindow(13) end end

	-- Evento abrir Guild do botão 4
	frameX = frameX + 436.0 frameY = frameY + 1.0
	if CheckMouseIn(frameX, frameY, 21.0, 22.0) and IsRelease(1) then if CheckWindow(6) then CloseWindow(6) else OpenWindow(6) end end

	-- Evento abrir Friends do botão 5
	frameX = frameX + 24.0 frameY = frameY + 0.5
	if CheckMouseIn(frameX, frameY, 21.0, 22.0) and IsRelease(1) then if CheckWindow(1) then CloseWindow(1) else OpenWindow(1) end end

	-- Evento abrir FastMenu do botão 6
	frameX = frameX + 24.0 frameY = frameY - 0.5
	if CheckMouseIn(frameX, frameY, 21.0, 22.0) and IsRelease(1) then if CheckWindow(34) then CloseWindow(34) else OpenWindow(34) end end
end

function HudRenderInterface()
	local frameX = ((GetWindowsX() / 2.0) - 320.0)
	local frameY = (GetWindowsY() - 72.0)

	RenderLife()	-- Renderiza as barras de Life e Mana

	-- Interface Principal
	RenderImage(IMAGE_MENU_1, frameX, frameY, 640.0, 72.0, 0.0, 22.0, 934.0, 106.0)

	 -- Número 100
	DrawBigNumber(frameX + 43.0, frameY + 65.0, 100, 0.6)

	-- Seta que informa a Skill Instance em uso, Skills de 1 a 5 e 6 a 0
	if NewSkillInstance() == false then
		RenderImage(IMAGE_MENU_2, frameX + 444, frameY + 42.0, 6.0, 12.0, 83.0, 19.0, -12.0, 22.0)
	else
		RenderImage(IMAGE_MENU_2, frameX + 445, frameY + 42.0, 6.0, 12.0, 71.0, 19.0, 12.0, 22.0)
	end

	RenderLifeHub()	-- Renderiza o ToolTip da Life e Mana

	RenderEnergy()	-- Renderiza o ToolTip e a barra de AG
	RenderShield()		-- Renderiza o ToolTip e a barra de SD

	HudButtonsRender() 	-- Botões da Interface

	return 1
end

function HudSkillRender()
	local frameX = ((GetWindowsX() / 2.0) - 320.0) + 332.5
	local frameY = (GetWindowsY() - 38.0)

	local SelectedSlot = { 0.0, 22.0, 44.5, 67.0, 88.5, 0.0, 22.0, 44.5, 67.0, 88.5 }
	local slots = (NewSkillInstance() == false) and {1, 2, 3, 4, 5} or  {6, 7, 8, 9, 0}

	-- Tamanho das skills (Original + Custom)
	SkillBoxSize(-1.0, -1.0)

	-- Posiciona e renderiza a skill registrada em uso
	SetCurrentSkillPosition(frameX - 26.0, frameY - 0.5)

	-- Obtem a skill em uso para comparar no loop
	local currentSkill = GetCurrentSkill()

	-- Quadro que fica por trás da skill selecionada
	for index, slot in ipairs(slots) do
		local offset = SelectedSlot[index]

		if GetSkillSlot(slot) == currentSkill then
			RenderImage(IMAGE_MENU_1, frameX - 1.0 + offset, frameY - 3.5, 23.0, 33.0, 443.0, 66.0, 37.0, 49.0)
		end
	end

	-- Posiciona e renderiza as skills de 0 a 9
	for index, slot in ipairs(slots) do
		local offset = SelectedSlot[index]

		if GetSkillSlot(slot) > -1 then
			SetSkillSlot(slot, frameX + offset + 1, frameY)
		end
	end

	return 1
end

function HudSkillNumber(X, Y, Number, Size)
	local FrameY = (GetWindowsY() - 51.0)

	-- Aplica 2 tamanhos de acordo com a posição da lista e das skills registradas
	if Y > 370.0 and Y < FrameY then
		Size = 0.8
		X = X - 5.0
		Y = Y - 5.0
	else
		Size = 0.9
		X = X - 3.0
		Y = Y - 1.5
	end

	DrawBigNumber(X, Y, Number, Size) -- Números das skills registradas de 0 a 9

	return 1
end

function HudMouseEvent()
	local frameX = ((GetWindowsX() / 2.0) - 320.0) + 332.5
	local frameY = (GetWindowsY() - 38.0)

	-- Evento do mouse sobre a skill registrada em uso
	if CheckMouseIn(frameX - 26.5, frameY - 1.0, 20, 28) and IsPress(1) then ToggleSkillList() end

	-- Evento do mouse sobre as skills registradas de 0 a 9
	SetInfoSkillSlot(-1)

	if NewSkillInstance() == false then
		if CheckMouseIn(frameX, frameY, 20, 28) and GetSkillSlot(1) > -1 then
			SetInfoSkillSlot(1)
			if IsPress(1) then SetCurrentSkill(1) end
		end
		if CheckMouseIn(frameX + 22.0, frameY, 20, 28) and GetSkillSlot(2) > -1 then
			SetInfoSkillSlot(2)
			if IsPress(1) then SetCurrentSkill(2) end
		end
		if CheckMouseIn(frameX + 44.5, frameY, 20, 28) and GetSkillSlot(3) > -1 then
			SetInfoSkillSlot(3)
			if IsPress(1) then SetCurrentSkill(3) end
		end
		if CheckMouseIn(frameX + 67.0, frameY, 20, 28) and GetSkillSlot(4) > -1 then
			SetInfoSkillSlot(4)
			if IsPress(1) then SetCurrentSkill(4) end
		end
		if CheckMouseIn(frameX + 88.5, frameY, 20, 28) and GetSkillSlot(5) > -1 then
			SetInfoSkillSlot(5)
			if IsPress(1) then SetCurrentSkill(5) end
		end
	else
		if CheckMouseIn(frameX, frameY, 20, 28) and GetSkillSlot(6) > -1 then
			SetInfoSkillSlot(6)
			if IsPress(1) then SetCurrentSkill(6) end
		end
		if CheckMouseIn(frameX + 22.0, frameY, 20, 28) and GetSkillSlot(7) > -1 then
			SetInfoSkillSlot(7)
			if IsPress(1) then SetCurrentSkill(7) end
		end
		if CheckMouseIn(frameX + 44.5, frameY, 20, 28) and GetSkillSlot(8) > -1 then
			SetInfoSkillSlot(8)
			if IsPress(1) then SetCurrentSkill(8) end
		end
		if CheckMouseIn(frameX + 67.0, frameY, 20, 28) and GetSkillSlot(9) > -1 then
			SetInfoSkillSlot(9)
			if IsPress(1) then SetCurrentSkill(9) end
		end
		if CheckMouseIn(frameX + 88.5, frameY, 20, 28) and GetSkillSlot(0) > -1 then
			SetInfoSkillSlot(0)
			if IsPress(1) then SetCurrentSkill(0) end
		end
	end

	HudButtonsEvent()	-- Evento do mouse sobre os botões da Interface

	return 1
end

function HudFunctionInit()
	QButtonPosition(179.0, 2.0)	-- Posição do Potion da tecla Q
	WButtonPosition(170.0, 2.0)	-- Posição do Potion da tecla W
	EButtonPosition(162.0, 2.0)	-- Posição do Potion da tecla E
	RButtonPosition(153.0, 2.0)	-- Posição do Potion da tecla R

	QNumberPosition(170.0, 4.0, 0.8)	-- Posição dos Números da tecla Q
	WNumberPosition(161.0, 4.0, 0.8)	-- Posição dos Números da tecla W
	ENumberPosition(153.0, 4.0, 0.8)	-- Posição dos Números da tecla E
	RNumberPosition(144.0, 4.0, 0.8)	-- Posição dos Números da tecla R

	ExperienceBar(61.0, 474.0, 534.0, 3.0)	-- Posição da barra de Experiência
	MasterExperienceBar(61.0, 474.0, 534.0, 3.0)	-- Posição da barra de Master Experiência

	ExpNumber(-31.0, 1.0, -0.2)	-- Posição do Número da Barra de Experiência

	HudSetLayerDepth(-5.0)	-- Posição z-Index para a Interface não ficar por cima do Chat
end

BridgeFunctionAttach("LuaLoadImages", "LoadHudImage")
BridgeFunctionAttach("LuaHudSkillRender", "HudSkillRender")
BridgeFunctionAttach("LuaHudSkillNumber", "HudSkillNumber")
BridgeFunctionAttach("LuaHudMouseEvent", "HudMouseEvent")
BridgeFunctionAttach("LuaHudInterface", "HudRenderInterface")
BridgeFunctionAttach("LuaEntryProc", "HudFunctionInit")