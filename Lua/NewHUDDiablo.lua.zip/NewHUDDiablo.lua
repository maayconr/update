require "System\\ScriptCore"

--ConsoleOn(1)

local HideNumberPotion = false
local ButtonBlink = false
local Delay = 0

local DIV_MainUI = 51235
local DIV_MainOrbLife = 51236
local DIV_MainOrbMana = 51237
local DIV_MainOrbPoison = 51238
local DIV_MainBarAG = 51240
local DIV_MainBarSD = 51241
local DIV_Notification = 51244
local DIV_BarPotion = 51245
local DIV_SkillBox = 51250
local DIV_HotKeySkillListUp = 51251

local CLOCKS_PER_SEC = 1000

local SOUND_HEART = 34 -- Som de batimento cardíaco

function LoadHudImage() -- Carregamento das imagens do client
	LoadImage("Interface\\NewHud\\Diablo\\DIV_MainUI.tga", DIV_MainUI)
	LoadImage("Interface\\NewHud\\Diablo\\DIV_MainOrbLife.tga", DIV_MainOrbLife)
	LoadImage("Interface\\NewHud\\Diablo\\DIV_MainOrbMana.tga", DIV_MainOrbMana)
	LoadImage("Interface\\NewHud\\Diablo\\DIV_MainOrbPoison.tga", DIV_MainOrbPoison)
	LoadImage("Interface\\NewHud\\Diablo\\DIV_MainBarAG.tga", DIV_MainBarAG)
	LoadImage("Interface\\NewHud\\Diablo\\DIV_MainBarSD.tga", DIV_MainBarSD)
	LoadImage("Interface\\NewHud\\Diablo\\DIV_Notification.tga", DIV_Notification)
	LoadImage("Interface\\NewHud\\Diablo\\DIV_BarPotion.tga", DIV_BarPotion)
	LoadImage("Interface\\NewHud\\Diablo\\DIV_SkillBox.tga", DIV_SkillBox)
	LoadImage("Interface\\NewHud\\Diablo\\DIV_HotKeySkillListUp.tga", DIV_HotKeySkillListUp)
end

function RenderFrameAnimation(Image, x, y, w, h, u, v, uw, vh, Time, cols, totalFrames, uFrame, vFrame) -- Função auxiliar para animar Life e Mana
	local factor = totalFrames / (Time * CLOCKS_PER_SEC)
	local frame = math.floor(GetTickCount() * factor) % totalFrames

	local fx = (frame % cols) * (uFrame ~= 0 and uFrame or uw)
	local fy = math.floor(frame / cols) * (vFrame ~= 0 and vFrame or vh)

	RenderImage(Image, x, y, w, h, u + fx, v + fy, uw, vh)
end

function clamp(value, minVal, maxVal) -- Função auxiliar para cálculo
	return math.min(math.max(value, minVal), maxVal)
end

function RenderLife() -- Calculo e renderização das barras de Life e Mana
	local fLife = 0.0
	local fMana = 0.0

	local wLifeMax
	local wLife
	local wManaMax
	local wMana

	wLifeMax = ViewMaxHP()
	wLife = clamp(ViewCurHP(), 0, wLifeMax)
	wManaMax = ViewMaxMP()
	wMana = clamp(ViewCurMP(), 0, wManaMax)

	if wLifeMax > 0 and (wLife > 0 and (wLife / wLifeMax) < 0.2) then
		PlaySound(SOUND_HEART);
	end

	if wLifeMax > 0 then
		fLife = (wLifeMax - wLife) / wLifeMax
	end
	
	if wManaMax > 0 then
		fMana = (wManaMax - wMana) / wManaMax
	end

	local frameX = ((GetWindowsX() / 2.0) - 320.0) + 16.5
	local frameY = (GetWindowsY() - 72.0) - 3

	local width = 64.0
	local height = 64.0
	local porcento = (1.0 - fLife)

	local iPosX = frameX + 108
	local iPosY = frameY + (fLife * height)
	local Height = (porcento * height)

	if IsBuffPoison() then
		RenderFrameAnimation(DIV_MainOrbPoison, iPosX, iPosY, width, Height, 0.0, (fLife * 128.0), 128.0, (porcento * 128.0), 1.44, 8, 64, 0.0, 128.0)
	else
		RenderFrameAnimation(DIV_MainOrbLife, iPosX, iPosY, width, Height, 0.0, (fLife * 128.0), 128.0, (porcento * 128.0), 1.44, 8, 64, 0.0, 128.0)
	end

	porcento = (1.0 - fMana)

	iPosX = frameX + 465
	iPosY = frameY + (fMana * height)
	Height = (porcento * height)

	RenderFrameAnimation(DIV_MainOrbMana, iPosX - 29.0, iPosY, width, Height, 0.0, (fMana * 128.0), 128.0, (porcento * 128.0), 1.44, 8, 64, 0.0, 128.0)
end

function RenderLifeHub() -- Renderização do ToolTip de Life e Mana
	local wLifeMax
	local wLife
	local wManaMax
	local wMana

	wLifeMax = ViewMaxHP()
	wLife = clamp(ViewCurHP(), 0, wLifeMax)
	wManaMax = ViewMaxMP()
	wMana = clamp(ViewCurMP(), 0, wManaMax)
	
	local frameX = ((GetWindowsX() / 2.0) - 320.0) + 108.0
	local frameY = (GetWindowsY() - 72.0)

	DrawBigNumber(frameX + 50.0, frameY + 25.0, wLife, 0.8)

	frameX = frameX + 379.0

	DrawBigNumber(frameX, frameY + 25.0, wMana, 0.8)
end

function RenderEnergy()
	local fSkillMana = 0.0
	local maxBP = ViewMaxBP()
	local curBP = ViewCurBP()

	if maxBP > 0 then
		fSkillMana = (maxBP - curBP) / maxBP
	end

	local frameX = ((GetWindowsX() / 2.0) - 320.0) + 411.0
	local frameY = (GetWindowsY() - 18.0)

	local width = 54.0
	local height = 5.5
	local percent = (1.0 - fSkillMana)

	local texW = 128.0
	local texH = 32.0

	local drawX = frameX + (fSkillMana * width)
	local drawWidth = percent * width

	local uvX = fSkillMana * texW
	local uvWidth = percent * texW

	RenderImage(DIV_MainBarAG, drawX, frameY, drawWidth, height, uvX, 0.0, uvWidth, texH)

	--if CheckMouseIn(frameX, frameY, width, height) then
		DrawBigNumber(frameX + 30.0, frameY - 1.0, curBP, 0.7)
	--end
end

function RenderShield() -- Calculo e renderização da barra de SD e ToolTip
	local fShield = 0.0
	local wMaxShield = ViewMaxSD()
	local wShield = ViewCurSD()

	if wMaxShield > 0 then
		fShield = (wMaxShield - wShield) / wMaxShield
	end

	local frameX = ((GetWindowsX() / 2.0) - 320.0) + 175.0
	local frameY = (GetWindowsY() - 18.0)

	local width = 54.0
	local height = 5.5
	local percent = (1.0 - fShield)

	local texW = 128.0
	local texH = 32.0
	
	local drawWidth = percent * width
	local uvWidth = percent * texW

	RenderImage(DIV_MainBarSD, frameX, frameY, drawWidth, height, 0.0, 0.0, uvWidth, texH)

	--if CheckMouseIn(frameX, frameY, width, height) then
		DrawBigNumber(frameX + 30.0, frameY - 1.0, wShield, 0.7)
	--end
end

function PotionNumberRender()
	if HideNumberPotion then
		MemorySet(0x0089580C, 0x90, 0x05)
		MemorySet(0x0089787C, 0x90, 0x05)
		MemorySet(0x00897A6C, 0x90, 0x05)
		MemorySet(0x00897C7C, 0x90, 0x05)
	else
		SetCompleteHook(0xE8, 0x0089580C, 0x005CF310)
		SetCompleteHook(0xE8, 0x0089787C, 0x005CF310)
		SetCompleteHook(0xE8, 0x00897A6C, 0x005CF310)
		SetCompleteHook(0xE8, 0x00897C7C, 0x005CF310)
	end

	QNumberPosition(20.0, 4.0, HideNumberPotion and 0.01 or 0.8)	-- Posição dos Números da tecla Q
	WNumberPosition(3.0, 4.0, HideNumberPotion and 0.01 or 0.8)	-- Posição dos Números da tecla W
	ENumberPosition(-13.0, 4.0, HideNumberPotion and 0.01 or 0.8)	-- Posição dos Números da tecla E
	RNumberPosition(-29.0, 4.0, HideNumberPotion and 0.01 or 0.8)	-- Posição dos Números da tecla R
end

function HudRenderInterface()
	local frameX = ((GetWindowsX() / 2.0) - 204.0)
	local frameY = (GetWindowsY() - 84.0)

	-- Background Potions
	if HideNumberPotion == false then
		RenderImage(DIV_BarPotion, frameX - 78.0, frameY + 44.0, 104, 30, 0.0, 0.0, 128.0, 32.0)
	end
	PotionNumberRender() -- Number Potion Render

	-- Interface Principal
	RenderImage(DIV_MainUI, frameX, frameY, 204.0, 82.0, 0.0, 0.0, 1009.0, 512.0)
	RenderImage(DIV_MainUI, frameX + 204.0, frameY, 204.0, 82.0, 14.0, 505.0, 1009.0, 512.0)

	-- Mostrador de Instance Skill Number
	RenderImage(DIV_HotKeySkillListUp, frameX + 122.0, frameY + 68.0, 134.0, 14.0, 0.0, 0.0, 1024.0, 85.0)
	RenderImage(DIV_HotKeySkillListUp, frameX + 122.0, frameY + 68.0, 134.0, 14.0, 0.0, NewSkillInstance() and 170.0 or 85.0, 1024.0, 85.0)

	if CheckMouseIn(frameX - 2, frameY + 44, 28, 30) then
		RenderImage(DIV_BarPotion, frameX - 78.0, frameY + 44.0, 104.0, 30.0, 0.0, 32.0, 128.0, 32.0)
	end

	if GetTickCount() - Delay >= 500 then
		ButtonBlink = not ButtonBlink
		Delay = GetTickCount()
	end

	if CheckQuestWarning() then
		if CheckWindow(69) == false and CheckWindow(16) == false then
			if ButtonBlink then
				RenderImage(DIV_Notification, frameX + 317.0, frameY + 11.0, 17.0, 17.0, 64.0, 0.0, 64.0, 64.0)
			end
		end
	end

	if CheckMailWarning() then
		if ButtonBlink then
			RenderImage(DIV_Notification, frameX + 332.0, frameY - 5.0, 17.0, 17.0, 0.0, 0.0, 64.0, 64.0)
		end
	end

	RenderLife()	-- Renderiza as barras de Life e Mana
	RenderLifeHub()	-- Renderiza o ToolTip da Life e Mana

	RenderEnergy()	-- Renderiza o ToolTip e a barra de AG
	RenderShield()		-- Renderiza o ToolTip e a barra de SD

	return 1
end

function HudSkillRender()
	local frameX = ((GetWindowsX() / 2.0) - 320.0) + 332.5
	local frameY = (GetWindowsY() - 38.0)

	local SelectedSlot = { -98.5, -69.0, -39.0, -9.5, 20.5, -98.5, -69.0, -39.0, -9.5, 20.5 }
	local slots = (NewSkillInstance() == false) and {1, 2, 3, 4, 5} or  {6, 7, 8, 9, 0}

	-- Tamanho das skills (Original + Custom)
	SkillBoxSize(4.0, -3.0)

	-- Posiciona e renderiza a skill registrada em uso
	RenderImage(DIV_SkillBox, frameX + 47.5, frameY - 10.5, 28.0, 29.5, 128.0, 0.0, 128.0, 128.0)
	SetCurrentSkillPosition(frameX + 49.0, frameY - 8.0)

	-- Obtem a skill em uso para comparar no loop
	local currentSkill = GetCurrentSkill()

	-- Quadro que fica por trás da skill selecionada
	for index, slot in ipairs(slots) do
		local offset = SelectedSlot[index]

		if GetSkillSlot(slot) == currentSkill then
			RenderImage(DIV_SkillBox, frameX + offset - 2.0, frameY - 11.0, 28.0, 29.5, 256.0, 0.0, 128.0, 128.0)
		end
	end

	-- Posiciona e renderiza as skills de 0 a 9
	for index, slot in ipairs(slots) do
		local offset = SelectedSlot[index]

		if GetSkillSlot(slot) > -1 then
			SetSkillSlot(slot, frameX + offset, frameY - 9.0)
		end
	end

	return 1
end

function HudSkillNumber(X, Y, Number, Size)
	local FrameY = (GetWindowsY() - 51.0)

	-- Aplica 2 tamanhos de acordo com a posição da lista e das skills registradas
	if Y > 370.0 and Y < FrameY then
		Size = 0.8
		X = X - 5.0
		Y = Y - 5.0
	else
		Size = 0.0
		X = X + 1.0
		Y = Y - 2.0
	end

	DrawBigNumber(X, Y, Number, Size) -- Números das skills registradas de 0 a 9

	return 1
end

function HudMouseEvent()
	local frameX = ((GetWindowsX() / 2.0) - 204.0)
	local frameY = (GetWindowsY() - 84.0)

	-- Click esconder números dos potions
	if CheckMouseIn(frameX - 2, frameY + 44, 28, 30) then
		if IsRelease(1) then
			if HideNumberPotion == false then HideNumberPotion = true else HideNumberPotion = false end
		end
	end

	-- Click Quest Warning
	if CheckQuestWarning() then
		if CheckMouseIn(frameX + 317.0, frameY + 11.0, 17.0, 17.0) then
			if IsPress(1) then
				OpenWindow(16)
				OpenWindow(4)
			end
		end
	end

	-- Click Main Warning
	if CheckMailWarning() then
		if CheckMouseIn(frameX + 332.0, frameY - 5.0, 17.0, 17.0) then
			if IsPress(1) then
				OpenWindow(1)
			end
		end
	end

	-- Posição Click Skills
	local frameX = frameX + 216.5
	local frameY = frameY + 46.0

	-- Evento do mouse sobre a skill registrada em uso
	if CheckMouseIn(frameX + 49.0, frameY - 7.5, 24, 25) and IsPress(1) then ToggleSkillList() end

	-- Evento do mouse sobre as skills registradas de 0 a 9
	SetInfoSkillSlot(-1)

	if NewSkillInstance() == false then
		if CheckMouseIn(frameX - 98.5, frameY - 8.0, 24, 25)  and GetSkillSlot(1) > -1 then
			SetInfoSkillSlot(1)
			if IsPress(1) then SetCurrentSkill(1) end
		end
		if CheckMouseIn(frameX - 69.0, frameY - 8.0, 24, 25)  and GetSkillSlot(2) > -1 then
			SetInfoSkillSlot(2)
			if IsPress(1) then SetCurrentSkill(2) end
		end
		if CheckMouseIn(frameX - 39.0, frameY - 8.0, 24, 25)  and GetSkillSlot(3) > -1 then
			SetInfoSkillSlot(3)
			if IsPress(1) then SetCurrentSkill(3) end
		end
		if CheckMouseIn(frameX - 9.5, frameY - 8.0, 24, 25)  and GetSkillSlot(4) > -1 then
			SetInfoSkillSlot(4)
			if IsPress(1) then SetCurrentSkill(4) end
		end
		if CheckMouseIn(frameX + 20.5, frameY - 8.0, 24, 25)  and GetSkillSlot(5) > -1 then
			SetInfoSkillSlot(5)
			if IsPress(1) then SetCurrentSkill(5) end
		end
	else
		if CheckMouseIn(frameX - 98.5, frameY - 8.0, 24, 25)  and GetSkillSlot(6) > -1 then
			SetInfoSkillSlot(6)
			if IsPress(1) then SetCurrentSkill(6) end
		end
		if CheckMouseIn(frameX - 69.0, frameY - 8.0, 24, 25)  and GetSkillSlot(7) > -1 then
			SetInfoSkillSlot(7)
			if IsPress(1) then SetCurrentSkill(7) end
		end
		if CheckMouseIn(frameX - 39.0, frameY - 8.0, 24, 25)  and GetSkillSlot(8) > -1 then
			SetInfoSkillSlot(8)
			if IsPress(1) then SetCurrentSkill(8) end
		end
		if CheckMouseIn(frameX - 9.5, frameY - 8.0, 24, 25)  and GetSkillSlot(9) > -1 then
			SetInfoSkillSlot(9)
			if IsPress(1) then SetCurrentSkill(9) end
		end
		if CheckMouseIn(frameX + 20.5, frameY - 8.0, 24, 25)  and GetSkillSlot(0) > -1 then
			SetInfoSkillSlot(0)
			if IsPress(1) then SetCurrentSkill(0) end
		end
	end

	return 1
end

function HudFunctionInit()
	QButtonPosition(30.0, 2.0)	-- Posição do Potion da tecla Q
	WButtonPosition(12.0, 2.0)	-- Posição do Potion da tecla W
	EButtonPosition(-4.0, 2.0)	-- Posição do Potion da tecla E
	RButtonPosition(-20.0, 2.0)	-- Posição do Potion da tecla R

	ExperienceBar(239.0, 423.0, 168.0, 4.0)	-- Posição da barra de Experiência
	MasterExperienceBar(239.0, 423.0, 168.0, 4.0)	-- Posição da barra de Master Experiência

	SetExpPosition(-10.0, -10.0)	-- Posição do tooltip da experiencia
	ExpNumber(-405.0, -51.0, -0.2)	-- Posição do Número da Barra de Experiência

	HudSetLayerDepth(-5.0)	-- Posição z-Index para a Interface não ficar por cima do Chat
end

function HudBlockWalk()
	local frameX = ((GetWindowsX() / 2.0) - 204.0)
	local frameY = (GetWindowsY() - 84.0)

	-- Não caminhar ao clicar no Quest Warning
	if CheckQuestWarning() then
		if CheckMouseIn(frameX + 317.0, frameY + 11.0, 17.0, 17.0) then
			return true
		end
	end

	-- Não caminhar ao clicar no Mail Warning
	if CheckMailWarning() then
		if CheckMouseIn(frameX + 332.0, frameY - 5.0, 17.0, 17.0) then
			return true
		end
	end

	return false
end

BridgeFunctionAttach("LuaLoadImages", "LoadHudImage")
BridgeFunctionAttach("LuaHudSkillRender", "HudSkillRender")
BridgeFunctionAttach("LuaHudSkillNumber", "HudSkillNumber")
BridgeFunctionAttach("LuaHudMouseEvent", "HudMouseEvent")
BridgeFunctionAttach("LuaHudInterface", "HudRenderInterface")
BridgeFunctionAttach("LuaEntryProc", "HudFunctionInit")
BridgeFunctionAttach("LuaMouseEvent", "HudBlockWalk");