require "System\\ScriptCore"
require "System\\ScriptDefines"

local ExpiraEm = 0
local LastTick = 0
local Window = 0
local Package = 0
local QrCode = ""

local ShowCPFBox = false
local InputCPF = ""
local CPFMessage = ""
local PackageInProcess = ""

PBText = {
    "Escolha seu pacote VIP!",
    "Vip Iron - 7 Days",
    "Vip Iron - 15 Days",
    "Vip Iron - 30 Days",
    "10,00 R$",
    "15,00 R$",
    "25,00 R$",
    "Comprar",
    "Loja de pacotes",
    "Morphes Pay - QrCode",
    "Confirmar",
}

-- =======================================================
-- RECEBE DADOS DO SERVIDOR
-- =======================================================
function BPRecv(aIndex, str)
    local Cmd, Step, Info, TimeLeft = string.match(str, "([^#]+)#([^#]*)#([^#]*)#?(%d*)")

    -- Sistema de compra VIP
    if Cmd == "buyvip" then
        if tonumber(Step) == 0 then
            QrCode = Info
            ExpiraEm = tonumber(TimeLeft) or 300
            LastTick = GetTickCount()
            Window = 2
            PackageInProcess = ""

        elseif tonumber(Step) == 1 then
            local status = tonumber(Info) or 0
            if status == 1 then
                Notice("Pagamento confirmado! Obrigado.", 0)
                ExpiraEm = 0
                QrCode = ""
                Window = 0
            else
                Notice("Pagamento cancelado ou expirado.", 0)
                ExpiraEm = 0
                QrCode = ""
                Window = 1
            end

        elseif tonumber(Step) == 2 then
            QrCode = ""
            Window = 1

        elseif tonumber(Step) == 3 then
            if Info ~= "" and tonumber(TimeLeft) and tonumber(TimeLeft) > 0 then
                QrCode = Info
                ExpiraEm = tonumber(TimeLeft)
                LastTick = GetTickCount()
                Window = 2
            else
                QrCode = ""
                ExpiraEm = 0
                Window = 1
            end
        end
    end

    if Cmd == "cpf" then
        local step = Step or ""
        if step == "request" then
            ShowCPFBox = true
            InputCPF = ""
            CPFMessage = "Digite seu CPF para continuar:"
        elseif step == "invalid" then
            ShowCPFBox = true
            InputCPF = ""
            CPFMessage = "CPF inválido! Tente novamente:"
        elseif step == "ok" then
            ShowCPFBox = false
            InputCPF = ""
            CPFMessage = ""

            if PackageInProcess ~= "" then
                Send(string.format("buyvip#0#%s#aftercpf", PackageInProcess))
                PackageInProcess = ""
            else
                Window = 1
            end
        end
    end
end

-- =======================================================
-- IMAGEM BASE
-- =======================================================
function LoadImageBP()
    LoadImage("Interface\\NewRender\\GeneralInterface.tga", 302000)
end

-- =======================================================
-- INTERFACE PRINCIPAL
-- =======================================================
function BPWork()
    local X = GetWindowsX() / 2 - 190 / 2
    local Y = 100

    if Window == 2 and ExpiraEm <= 0 and QrCode ~= "" then
        QrCode = ""
        ExpiraEm = 0
        LastTick = 0
        Window = 1
    end

    SetBlend(1)
    glColor(255, 255, 255, 255)

    if Window > 0 then
        DrawBarBorder(255, 255, 255, 0, 0, 255, 0, 255, (GetWindowsX() / 2) + 294, GetWindowsY() - 75, 25, 21)
    end

    RenderItem((GetWindowsX() / 2) + 297, GetWindowsY() - 73, 20, 20, ((512*14)+137), 0, 0, 0, 0.5)

    if Window > 0 then
        RenderImage(302000, X, Y, 190, 65, 0, 0, 332, 94)
        RenderImage(302000, X, Y + 65, 190, 125, 0, 94, 332, 585)
        RenderImage(302000, X, Y + 180, 190, 34, 0, 678, 332, 34)

        if CheckMouseIn(X + 155, Y + 28, 15, 15) then
            if IsRepeat(0x01) then
                RenderImage(302000, X + 155, Y + 28.5, 15, 15, 226, 871, 21, 21)
            else
                RenderImage(302000, X + 155, Y + 28.5, 15, 15, 205, 870, 21, 21)
            end
        else
            RenderImage(302000, X + 155, Y + 28.5, 15, 15, 226, 829, 21, 21)
        end
    end

    -- =======================
    -- LOJA DE PACOTES (Window 1)
    -- =======================
    if Window == 1 then
        for i = 0, 2 do
            RenderImage(302000, X + 17 + (i * 53), Y + 65, 50, 50, 325, 783, 407, 238)
            if Package - 1 == i then
                DrawBarBorder(255, 255, 255, 0, 0, 255, 0, 255, X + 17 + (i * 53), Y + 65, 50, 50)
            end
        end

        local Comp = 0 if Package > 0 then Comp = 1 end
        local Color = 150 if Package > 0 then Color = 200 end

        if CheckMouseIn(X + (190/2) - 40, Y + 160, 80, 25) and Package > 0 then
            if IsRepeat(0x01) then
                RenderImage(302000, X + (190/2) - 40, Y + 160, 80, 25, 439, 270, 122, 33)
                CustomText(Comp, 15, X + (190/2) - 40, Y + 167.5, 255, 255, 255, 220, 0, 0, 0, 0, 80, 3, PBText[8])
            else
                RenderImage(302000, X + (190/2) - 40, Y + 160, 80, 25, 439, 351, 122, 33)
                CustomText(Comp, 15, X + (190/2) - 40, Y + 167.5, 255, 255, 255, 220, 0, 0, 0, 0, 80, 3, PBText[8])
            end
        else
            RenderImage(302000, X + (190/2) - 40, Y + 160, 80, 25, 439, 310, 122, 33)
            CustomText(Comp, 15, X + (190/2) - 40, Y + 167.5, 255, 255, 255, Color, 0, 0, 0, 0, 80, 3, PBText[8])
        end

        CustomText(1, 16, X + 20, Y + 32, 255, 215, 0, 220, 0, 0, 0, 0, 150, 3, PBText[9])

        RenderItem(X + 17, Y + 65, 50, 50, ((512*14)+134), 0, 0, 0, 0.0)
        RenderItem(X + 70, Y + 65, 50, 50, ((512*14)+139), 0, 0, 0, 0.0)
        RenderItem(X + 123, Y + 65, 50, 50, ((512*14)+136), 0, 0, 0, 0.0)
        CustomText(0, 15, X, Y + 125, 255, 255, 255, 220, 0, 0, 0, 0, 190, 3, PBText[Package+1])

        if Package > 0 then
            CustomText(0, 15, X, Y + 140, 255, 255, 255, 220, 0, 0, 0, 0, 190, 3, PBText[Package + 4])
        end
    end

	if ExpiraEm > 0 then
        local now = GetTickCount()
        local elapsed = (now - LastTick) / 1000
        if elapsed >= 1 then
            ExpiraEm = ExpiraEm - math.floor(elapsed)
            if ExpiraEm < 0 then ExpiraEm = 0 end
            LastTick = now
        end
    end

    -- =======================
    -- PAGAMENTO / CPF (Window 2)
    -- =======================
    if Window == 2 then
        CustomText(1, 16, X + 20, Y + 32, 255, 215, 0, 220, 0, 0, 0, 0, 150, 3, PBText[10])

        if ShowCPFBox then
            CustomText(1, 14, X + 15, Y + 110, 255, 215, 0, 255, 0, 0, 0, 255, 160, 3, CPFMessage)
            CustomText(0, 15, X + 15, Y + 130, 255, 255, 255, 255, 0, 0, 0, 255, 160, 3, InputCPF .. "_")

            local ButtonX = X + (190/2) - 40
            local ButtonY = Y + 160
            local Comp = 0 if #InputCPF >= 11 then Comp = 1 end
            local Color = 150 if #InputCPF >= 11 then Color = 200 end

            if CheckMouseIn(ButtonX, ButtonY, 80, 25) and #InputCPF >= 11 then
                if IsRepeat(0x01) then
                    RenderImage(302000, ButtonX, ButtonY, 80, 25, 439, 270, 122, 33)
                    CustomText(Comp, 15, ButtonX, ButtonY + 7.5, 255, 255, 255, 220, 0, 0, 0, 0, 80, 3, PBText[11])
                else
                    RenderImage(302000, ButtonX, ButtonY, 80, 25, 439, 351, 122, 33)
                    CustomText(Comp, 15, ButtonX, ButtonY + 7.5, 255, 255, 255, 220, 0, 0, 0, 0, 80, 3, PBText[11])
                end
            else
                RenderImage(302000, ButtonX, ButtonY, 80, 25, 439, 310, 122, 33)
                CustomText(Comp, 15, ButtonX, ButtonY + 7.5, 255, 255, 255, Color, 0, 0, 0, 0, 80, 3, PBText[11])
            end
        elseif QrCode ~= "" then
            QrCode = string.gsub(QrCode, "\\/", "/")
            if ExpiraEm > 0 then
                local min = math.floor(ExpiraEm / 60)
                local sec = ExpiraEm % 60
                CustomText(0, 14, X, Y + 175, 255, 255, 255, 220, 0, 0, 0, 0, 190, 3, string.format("Expira em: %02d:%02d", min, sec))
            else
                CustomText(0, 14, X, Y + 175, 255, 100, 100, 220, 0, 0, 0, 0, 190, 3, "QR Code expirado")
            end
            PrintQRCode(X + (190/2) - 50, Y + 65, 100, QrCode)
        else
            CustomText(0, 15, X, Y + 110, 255, 255, 255, 220, 0, 0, 0, 0, 190, 3, "Obtendo QR Code...")
        end
    end
end

-- =======================================================
-- EVENTOS DE MOUSE / TECLADO
-- =======================================================
function BPEvent()
    local X = GetWindowsX() / 2 - 190 / 2
    local Y = 100

    if Window == 2 and ShowCPFBox then
        local ButtonX = X + (190/2) - 40
        local ButtonY = Y + 160

        if CheckMouseIn(ButtonX, ButtonY, 80, 25) and IsPress(0x01) then
            if #InputCPF >= 11 then
                Send("cpf#" .. InputCPF)
                return true
            else
                CPFMessage = "Digite o CPF completo (11 dígitos)."
                return true
            end
        end

        if CheckMouseIn(X + 155, Y + 28, 15, 15) and IsRelease(0x01) then
            Window = 0
            ShowCPFBox = false
            return true
        end

        if IsRelease(0x08) and #InputCPF > 0 then
            InputCPF = string.sub(InputCPF, 1, -2)
            return true
        end

        for i = 48, 57 do
            if IsRelease(i) then
                if #InputCPF < 11 then
                    InputCPF = InputCPF .. string.char(i)
                end
                return true
            end
        end
        return true
    end

    if CheckMouseIn((GetWindowsX() / 2) + 296, GetWindowsY() - 75, 21, 22) and IsRelease(0x01) then
        if Window == 0 then
            Send("buyvip#check#")
        else
            Window = 0
        end
        return true
    end

    if Window == 1 then
        local clicked = IsPress(0x01)
        for i = 0, 2 do
            if CheckMouseIn(X + 17 + (i * 53), Y + 65, 50, 50) and clicked then
                Package = i + 1
            end
        end

        if Package > 0 and CheckMouseIn(X + (190 / 2) - 40, Y + 160, 80, 25) and IsRelease(0x01) then
            local pacote = (Package == 1 and "vip7") or (Package == 2 and "vip15") or "vip30"
            PackageInProcess = pacote
            Send(string.format("buyvip#0#%s", pacote))
            Window = 2
            return true
        end
    end

    if Window > 0 then
        if CheckMouseIn(X + 155, Y + 28, 15, 15) and IsRelease(0x01) then
            Window = 0
            return true
        end
    end
end

-- =======================================================
-- REGISTROS
-- =======================================================
BridgeFunctionAttach("LuaPacketRecv", "BPRecv")
BridgeFunctionAttach("LuaLoadImages", "LoadImageBP")
BridgeFunctionAttach("LuaWork", "BPWork")
BridgeFunctionAttach("LuaMouseEvent", "BPEvent")
