require "System\\ScriptCore"

ConsoleOn(1)

local ButtonBlink = false
local Delay = 0

local DIV_MainUI = 51235
local DIV_MainOrbLife = 51236
local DIV_MainOrbMana = 51237
local DIV_MainOrbPoison = 51238
local DIV_Notification = 51244
local DIV_SkillBox = 51250

local CLOCKS_PER_SEC = 1000

local SOUND_HEART = 34 -- Som de batimento cardíaco

function LoadHudImage() -- Carregamento das imagens do client
	LoadImage("Interface\\NewHud\\Matrix\\NewHud.tga", DIV_MainUI)
	LoadImage("Interface\\NewHud\\Matrix\\DIV_MainOrbLife.tga", DIV_MainOrbLife)
	LoadImage("Interface\\NewHud\\Matrix\\DIV_MainOrbMana.tga", DIV_MainOrbMana)
	LoadImage("Interface\\NewHud\\Matrix\\DIV_MainOrbPoison.tga", DIV_MainOrbPoison)
	LoadImage("Interface\\NewHud\\Matrix\\DIV_Notification.tga", DIV_Notification)
	LoadImage("Interface\\NewHud\\Matrix\\DIV_SkillBox.tga", DIV_SkillBox)
end

function RenderFrameAnimation(Image, x, y, w, h, u, v, uw, vh, Time, cols, totalFrames, uFrame, vFrame) -- Função auxiliar para animar Life e Mana
	local factor = totalFrames / (Time * CLOCKS_PER_SEC)
	local frame = math.floor(GetTickCount() * factor) % totalFrames

	local fx = (frame % cols) * (uFrame ~= 0 and uFrame or uw)
	local fy = math.floor(frame / cols) * (vFrame ~= 0 and vFrame or vh)

	RenderImage(Image, x, y, w, h, u + fx, v + fy, uw, vh)
end

function clamp(value, minVal, maxVal) -- Função auxiliar para cálculo
	return math.min(math.max(value, minVal), maxVal)
end

function RenderLife() -- Calculo e renderização das barras de Life e Mana
	local fLife = 0.0
	local fMana = 0.0

	local wLifeMax
	local wLife
	local wManaMax
	local wMana

	wLifeMax = ViewMaxHP()
	wLife = clamp(ViewCurHP(), 0, wLifeMax)
	wManaMax = ViewMaxMP()
	wMana = clamp(ViewCurMP(), 0, wManaMax)

	if wLifeMax > 0 and (wLife > 0 and (wLife / wLifeMax) < 0.2) then
		PlaySound(SOUND_HEART);
	end

	if wLifeMax > 0 then
		fLife = (wLifeMax - wLife) / wLifeMax
	end
	
	if wManaMax > 0 then
		fMana = (wManaMax - wMana) / wManaMax
	end

	local frameX = ((GetWindowsX() / 2.0) - 320.0) + 16.5
	local frameY = (GetWindowsY() - 72.0) + 8.0

	local width = 50.0
	local height = 46.0
	local porcento = (1.0 - fLife)

	local iPosX = frameX + 160.5
	local iPosY = frameY + (fLife * height)
	local Height = (porcento * height)

	if IsBuffPoison() then
		glColor(255, 255, 255, 120)
		RenderFrameAnimation(DIV_MainOrbPoison, iPosX, frameY, width, height, 0.0, 0.0, 128.0, 128.0, 1.44, 8, 64, 0.0, 128.0)
		glColor(255, 255, 255, 255)
		RenderFrameAnimation(DIV_MainOrbPoison, iPosX, iPosY, width, Height, 0.0, (fLife * 128.0), 128.0, (porcento * 128.0), 1.44, 8, 64, 0.0, 128.0)
		glColor(255, 255, 255, 255)
	else
		glColor(255, 255, 255, 120)
		RenderFrameAnimation(DIV_MainOrbLife, iPosX, frameY, width, height, 0.0, 0.0, 128.0, 128.0, 1.44, 8, 64, 0.0, 128.0)
		glColor(255, 255, 255, 255)
		RenderFrameAnimation(DIV_MainOrbLife, iPosX, iPosY, width, Height, 0.0, (fLife * 128.0), 128.0, (porcento * 128.0), 1.44, 8, 64, 0.0, 128.0)
		glColor(255, 255, 255, 255)
	end

	porcento = (1.0 - fMana)

	iPosX = frameX + 425.5
	iPosY = frameY + (fMana * height)
	Height = (porcento * height)

	local fixedY = frameY
	local fixedHeight = height

	glColor(255, 255, 255, 100)
	RenderFrameAnimation(DIV_MainOrbMana, iPosX - 29.0, frameY, width, height, 0.0, 0.0, 128.0, 128.0, 1.44, 8, 64, 0.0, 128.0)
	glColor(255, 255, 255, 255)

	RenderFrameAnimation(DIV_MainOrbMana, iPosX - 29.0, iPosY, width, Height, 0.0, (fMana * 128.0), 128.0, (porcento * 128.0), 1.44, 8, 64, 0.0, 128.0)
end

function RenderLifeHub() -- Renderização do ToolTip de Life e Mana
	local wLifeMax
	local wLife
	local wManaMax
	local wMana

	wLifeMax = ViewMaxHP()
	wLife = clamp(ViewCurHP(), 0, wLifeMax)
	wManaMax = ViewMaxMP()
	wMana = clamp(ViewCurMP(), 0, wManaMax)
	
	local frameX = ((GetWindowsX() / 2.0) - 320.0) + 108.0
	local frameY = (GetWindowsY() - 72.0)

	DrawBigNumber(frameX + 96.0, frameY + 26.0, wLife, 0.8)

	frameX = frameX + 379.0

	DrawBigNumber(frameX - 46, frameY + 26.0, wMana, 0.8)
end

function RenderEnergy()
	local fSkillMana = 0.0
	local maxBP = ViewMaxBP()
	local curBP = ViewCurBP()

	if maxBP > 0 then
		fSkillMana = (maxBP - curBP) / maxBP
	end

	local percent = (1.0 - fSkillMana)

	local frameX = ((GetWindowsX() / 2.0) - 320.0) + 411.0
	local frameY = (GetWindowsY() - 18.0)

	local totalWidth = 78.5
	local drawWidth = totalWidth * percent

	local XXX = (78.5) - drawWidth;

	DrawBar(115, 0, 155, 255, frameX - 77.5 + XXX, frameY + 1.0, drawWidth, 5.0)

	DrawBigNumber(frameX - 35.0, frameY + 0.5, curBP, 0.65)
end

function RenderShield()
	local fShield = 0.0
	local wMaxShield = ViewMaxSD()
	local wShield = ViewCurSD()

	if wMaxShield > 0 then
		fShield = (wMaxShield - wShield) / wMaxShield
	end

	local percent = (1.0 - fShield)

	local frameX = ((GetWindowsX() / 2.0) - 320.0) + 175.0
	local frameY = (GetWindowsY() - 18.0)

	local totalWidth = 78.5
	local drawWidth = totalWidth * percent

	DrawBar(155, 115, 0, 255, frameX + 53.0, frameY + 1.0, drawWidth, 5.0)

	DrawBigNumber(frameX + 95.0, frameY + 0.5, wShield, 0.65)
end

function PotionNumberRender()
	QNumberPosition(217.0, -34.5, 0.6)	-- Posição dos Números da tecla Q
	WNumberPosition(195.5, -34.5, 0.6)	-- Posição dos Números da tecla W
	ENumberPosition(174.0, -34.5, 0.6)		-- Posição dos Números da tecla E
	RNumberPosition(152.5, -34.5, 0.6)	-- Posição dos Números da tecla R
end

function HudRenderInterface()
	local frameX = ((GetWindowsX() / 2.0) - (301.0 / 2))
	local frameY = (GetWindowsY() - 77.0)

	RenderLife()	-- Renderiza as barras de Life e Mana

	PotionNumberRender() -- Number Potion Render

	-- Interface Principal
	RenderImage(DIV_MainUI, frameX, frameY, 301.0, 76.0, 0.0, 0.0, 1018.0, 268.0)

	if GetTickCount() - Delay >= 500 then
		ButtonBlink = not ButtonBlink
		Delay = GetTickCount()
	end

	if CheckQuestWarning() then
		if CheckWindow(69) == false and CheckWindow(16) == false then
			if ButtonBlink then
				RenderImage(DIV_Notification, frameX + 220.0, frameY - 4.0, 17.0, 17.0, 64.0, 0.0, 64.0, 64.0)
			end
		end
	end

	if CheckMailWarning() then
		if ButtonBlink then
			RenderImage(DIV_Notification, frameX + 200.0, frameY - 4.0, 17.0, 17.0, 0.0, 0.0, 64.0, 64.0)
		end
	end

	RenderLifeHub()	-- Renderiza o ToolTip da Life e Mana

	RenderEnergy()	-- Renderiza o ToolTip e a barra de AG
	RenderShield()		-- Renderiza o ToolTip e a barra de SD

	return 1
end

function HudSkillRender()
	local frameX = ((GetWindowsX() / 2.0) - 320.0) + 332.5
	local frameY = (GetWindowsY() - 38.0)

	local SelectedSlot = { -27.3, -11.0, 6.0, 22.0, 38.5, -27.3, -11.0, 6.0, 22.0, 38.5 }
	local slots = (NewSkillInstance() == false) and {1, 2, 3, 4, 5} or  {6, 7, 8, 9, 0}

	-- Tamanho das skills (Original + Custom)
	SkillBoxSize(-7.0, -12.0)

	-- Posiciona e renderiza a skill registrada em uso
	SetCurrentSkillPosition(frameX + 54.5, frameY - 12.5)

	-- Obtem a skill em uso para comparar no loop
	local currentSkill = GetCurrentSkill()

	-- Quadro que fica por trás da skill selecionada
	for index, slot in ipairs(slots) do
		local offset = SelectedSlot[index]

		if GetSkillSlot(slot) == currentSkill then
			RenderImage(DIV_SkillBox, frameX + offset - 2.0, frameY - 14.5, 17.0, 20.0, 128.0, 0.0, 128.0, 128.0)
		end
	end

	-- Posiciona e renderiza as skills de 0 a 9
	for index, slot in ipairs(slots) do
		local offset = SelectedSlot[index]

		if GetSkillSlot(slot) > -1 then
			SetSkillSlot(slot, frameX + offset, frameY - 12.5)
		end
	end

	return 1
end

function HudSkillNumber(X, Y, Number, Size)
	local FrameY = (GetWindowsY() - 51.0)

	-- Aplica 2 tamanhos de acordo com a posição da lista e das skills registradas
	if Y > 370.0 and Y < FrameY then
		Size = 0.8
		X = X - 5.0
		Y = Y - 5.0
	else
		Size = 0.6
		X = X - 13.0
		Y = Y - 27.0
	end

	DrawBigNumber(X, Y, Number, Size) -- Números das skills registradas de 0 a 9

	return 1
end

function HudMouseEvent()
	local frameX = ((GetWindowsX() / 2.0) - 150.5)
	local frameY = (GetWindowsY() - 77.0)
	
	-- Click Quest Warning
	if CheckQuestWarning() then
		if CheckMouseIn(frameX + 220.0, frameY - 4.0, 17.0, 17.0) then
			if IsPress(1) then
				OpenWindow(16)
				OpenWindow(4)
			end
		end
	end

	-- Click Main Warning
	if CheckMailWarning() then
		if CheckMouseIn(frameX + 200.0, frameY - 4.0, 17.0, 17.0) then
			if IsPress(1) then
				OpenWindow(1)
			end
		end
	end

	frameX = ((GetWindowsX() / 2.0) - 320.0) + 332.5
	frameY = (GetWindowsY() - 38.0)

	-- Evento do mouse sobre a skill registrada em uso
	if CheckMouseIn(frameX + 55, frameY - 12, 13, 16) and IsPress(1) then ToggleSkillList() end

	-- Evento do mouse sobre as skills registradas de 0 a 9
	SetInfoSkillSlot(-1)

	if NewSkillInstance() == false then
		if CheckMouseIn(frameX - 27.3, frameY - 12.5, 13, 16)  and GetSkillSlot(1) > -1 then
			SetInfoSkillSlot(1)
			if IsPress(1) then SetCurrentSkill(1) end
		end
		if CheckMouseIn(frameX - 11.0, frameY - 12.5, 13, 16)  and GetSkillSlot(2) > -1 then
			SetInfoSkillSlot(2)
			if IsPress(1) then SetCurrentSkill(2) end
		end
		if CheckMouseIn(frameX + 6.0, frameY - 12.5, 13, 16)  and GetSkillSlot(3) > -1 then
			SetInfoSkillSlot(3)
			if IsPress(1) then SetCurrentSkill(3) end
		end
		if CheckMouseIn(frameX + 22.0, frameY - 12.5, 13, 16)  and GetSkillSlot(4) > -1 then
			SetInfoSkillSlot(4)
			if IsPress(1) then SetCurrentSkill(4) end
		end
		if CheckMouseIn(frameX + 38.5, frameY - 12.5, 13, 16)  and GetSkillSlot(5) > -1 then
			SetInfoSkillSlot(5)
			if IsPress(1) then SetCurrentSkill(5) end
		end
	else
		if CheckMouseIn(frameX - 27.3, frameY - 8.0, 13, 16)  and GetSkillSlot(6) > -1 then
			SetInfoSkillSlot(6)
			if IsPress(1) then SetCurrentSkill(6) end
		end
		if CheckMouseIn(frameX - 11.0, frameY - 8.0, 13, 16)  and GetSkillSlot(7) > -1 then
			SetInfoSkillSlot(7)
			if IsPress(1) then SetCurrentSkill(7) end
		end
		if CheckMouseIn(frameX + 6.0, frameY - 8.0, 13, 16)  and GetSkillSlot(8) > -1 then
			SetInfoSkillSlot(8)
			if IsPress(1) then SetCurrentSkill(8) end
		end
		if CheckMouseIn(frameX + 22.0, frameY - 8.0, 13, 16)  and GetSkillSlot(9) > -1 then
			SetInfoSkillSlot(9)
			if IsPress(1) then SetCurrentSkill(9) end
		end
		if CheckMouseIn(frameX + 38.5, frameY - 8.0, 13, 16)  and GetSkillSlot(0) > -1 then
			SetInfoSkillSlot(0)
			if IsPress(1) then SetCurrentSkill(0) end
		end
	end

	return 1
end

function HudFunctionInit()
	QButtonPosition(227.0, -16.0)	-- Posição do Potion da tecla Q
	WButtonPosition(205.0, -16.0)	-- Posição do Potion da tecla W
	EButtonPosition(184.0, -16.0)	-- Posição do Potion da tecla E
	RButtonPosition(162.0, -16.0)	-- Posição do Potion da tecla R

	ExperienceBar(236.0, 450.5, 166.0, 5.0)	-- Posição da barra de Experiência
	MasterExperienceBar(236.0, 450.5, 166.0, 5.0)	-- Posição da barra de Master Experiência

	SetExpPosition(-10.0, -15.0)	-- Posição do tooltip da experiencia
	ExpNumber(-315.5, -11.5, -0.2)	-- Posição do Número da Barra de Experiência

	HudSetLayerDepth(-5.0)	-- Posição z-Index para a Interface não ficar por cima do Chat
end

function HudBlockWalk()
	local frameX = ((GetWindowsX() / 2.0) - 188.0)
	local frameY = (GetWindowsY() - 97.0)

	if CheckMouseIn(frameX, frameY, 376.0, 95.0) then
		return true
	end

	return false
end

BridgeFunctionAttach("LuaLoadImages", "LoadHudImage")
BridgeFunctionAttach("LuaHudSkillRender", "HudSkillRender")
BridgeFunctionAttach("LuaHudSkillNumber", "HudSkillNumber")
BridgeFunctionAttach("LuaHudMouseEvent", "HudMouseEvent")
BridgeFunctionAttach("LuaHudInterface", "HudRenderInterface")
BridgeFunctionAttach("LuaEntryProc", "HudFunctionInit")
BridgeFunctionAttach("LuaMouseEvent", "HudBlockWalk");